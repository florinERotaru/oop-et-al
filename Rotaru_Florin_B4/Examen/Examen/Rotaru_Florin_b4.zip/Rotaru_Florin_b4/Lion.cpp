#include "Lion.h"

int Lion::GetSpeed() {
    return 100;
}

std::string Lion::GetName() {
    return "Lion";
}

bool Lion::IsAFish() {
    return false;
}

bool Lion::IsABird() {
    return false;
}

bool Lion::IsAMammal() {
    return true;
}
