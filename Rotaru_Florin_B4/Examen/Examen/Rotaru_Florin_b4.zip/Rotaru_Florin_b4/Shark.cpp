#include "Shark.h"

std::string Shark::GetName() {
    return "Shark";
}

bool Shark::IsAFish() {
    return false;
}

bool Shark::IsABird() {
    return true;
}

bool Shark::IsAMammal() {
    return false;
}
