#include "Tiger.h"

int Tiger::GetSpeed() {
    return 100;
}

std::string Tiger::GetName() {
    return "Tiger";
}

bool Tiger::IsAFish() {
    return false;
}

bool Tiger::IsABird() {
    return false;
}

bool Tiger::IsAMammal() {
    return true;
}
