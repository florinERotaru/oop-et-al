#include "Eagle.h"

std::string Eagle::GetName() {
    return "Eagle";
}

bool Eagle::IsAFish() {
    return false;
}

bool Eagle::IsABird() {
    return true;
}

bool Eagle::IsAMammal() {
    return false;
}
